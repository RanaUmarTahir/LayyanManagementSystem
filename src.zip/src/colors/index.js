export const appColors = {
    white: '#FFFFFF',
    black: '#000000',
    
}