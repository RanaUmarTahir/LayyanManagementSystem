import { View, Text, StyleSheet, FlatList } from 'react-native'
import React from 'react'
import { Classname } from '../../../components/classnName/className'


const Attendance = (props) => {
    const data = [
        {
            name: 'Class1',
        },
        {
            name: 'Class2',
        },
        {
            name: 'Class3',
        },
    ]
    const renderItem = ({ item }) => {
        return <Classname name={item.name} props={props}
        />
    }
    return (
        <View>
            <Text style={styles.Testa}>
                Class
            </Text>
            <View style={styles.Testb}>
                <FlatList data={data} renderItem={renderItem} />

            </View>

        </View>
    )
}

const styles = StyleSheet.create({
    Testa: {
        alignSelf: 'center',
        fontWeight: 'bold',
        fontSize: 25,
        marginTop: 10,
    },
    Testb: {
        backgroundColor: 'gray',
        borderRadius: 20,
        margin: 15,
        padding: 10,




    },

})
export default Attendance