import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native'
import React from 'react'
import { MarkAttendace } from '../../../components/markAttendance/markAttendance'

const addAttendance = (props) => {

    const renderItem = ({ item, index }) => {
        return (
            <View style={{ marginVertical: 10 }}>
                <MarkAttendace
                    name={'Farhan'}
                    attendance={'P'}
                    onPressView={() => props.navigation.navigate('veiwAttendance')}
                />
            </View>
        )
    }
    return (
        <View style={{ marginHorizontal: 20 }}>
            <View style={styles.header}>
                <View style={{ ...styles.adbtn, backgroundColor: 'transparent' }} />
                <Text style={styles.Testa}>
                    Add Attendance
                </Text>
                <TouchableOpacity style={styles.adbtn}>
                    <Text style={styles.addtext}>
                        Add
                    </Text>
                </TouchableOpacity>
            </View>


            <Text style={styles.Testb}>
                Date24/07/2023
            </Text>
            <View style={styles.Testb}>
                <FlatList data={[1, 1, 1, 1]} renderItem={renderItem} />

            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    Testa: {
        alignSelf: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    adbtn: {
        borderRadius: 10,
        height: 35,
        width: 90,
        backgroundColor: "gray",
        // borderRadius: 10,
        alignItems: "center",
        justifyContent: 'center'

    },
    addtext: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#fff',
        textAlign: 'center'
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        // marginHorizontal: 15,
        marginTop: 10
    }
    // Testb: {
    // //     fontWeight: 10,
    // //     alignSelf: 'left'
    //     //
    // },
})
export default addAttendance