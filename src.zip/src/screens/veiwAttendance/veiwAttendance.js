import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native'
import React, { useState } from 'react'
import { width } from "react-native-dimension";

const veiwAttendance = () => {
    const [selectType, setSelectType] = useState('Present Day')

    let data = [
        {
            id: 1,
            date: '31/12/2023'
        },
        {
            id: 2,
            date: '1/1/2024'
        },
    ]

    return (
        <View>
            <Text style={styles.TextA}>
                Monthly Attendance
            </Text>

            <Text style={styles.TextB}>
                Select Month 07/2023
            </Text>

            <View style={styles.header}>
                <TouchableOpacity onPress={() => setSelectType('Present Day')} style={{
                    ...styles.TextC,
                    backgroundColor: selectType == 'Present Day' ? 'blue' : 'red',
                }}>
                    <Text style={{ color: 'white' }}>Present Day</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => setSelectType('Absent Day')} style={{
                    ...styles.TextC,
                    backgroundColor: selectType == 'Absent Day' ? 'blue' : 'red',
                }}>
                    <Text style={{ color: 'white' }}>Absent Day</Text>
                </TouchableOpacity>

            </View>
            <Text style={styles.TextE}>
                Total Present Day: 10
            </Text>

            <View style={styles.flatlistView}>
                <FlatList
                    data={selectType == 'Present Day' ? data : []}
                    ListEmptyComponent={() => {
                        return (
                            <View style={styles.dateView}>
                                <Text>No Data Available</Text>
                            </View>
                        )
                    }}
                    renderItem={({ item, index }) => {
                        return (
                            <View style={styles.dateView}>
                                <Text>{item?.date}</Text>
                            </View>
                        )
                    }}
                />
            </View>

        </View>
    )
}
const styles = StyleSheet.create({
    TextA: {
        alignSelf: 'center',
        fontWeight: 'bold',
        marginTop: 10,
        fontSize: 20,
    },
    TextB: {
        alignSelf: 'center',
        marginVertical: 15,
    },
    TextC: {
        marginHorizontal: 15,
        borderRadius: 100,
        width: width(40),
        height: width(12),
        alignItems: 'center',
        justifyContent: 'center',
    },
    header: {
        flexDirection: 'row',
    },
    TextE: {
        alignSelf: 'center',
        marginTop: 10,
    },
    flatlistView: {
        backgroundColor: "gray",
        marginHorizontal: width(4),
        padding: width(4),
        borderRadius: 10,
        marginTop: 20
    },
    dateView: {
        backgroundColor: 'white',
        padding: width(4),
        borderRadius: 10,
        marginVertical: 10
    },
})


export default veiwAttendance