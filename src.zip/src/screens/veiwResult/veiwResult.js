import { View, Text, StyleSheet, FlatList } from 'react-native'
import React from 'react'
import { width, height } from "react-native-dimension";

const veiwResult = () => {
    let data = [
        {
            id: 1,
            subject: 'Math',
            total: '100',
            obtain: '50'
        },
        {
            id: 2,
            subject: 'English',
            total: '100',
            obtain: '70'
        },
        {
            id: 3,
            subject: 'Urdu',
            total: '100',
            obtain: '20'
        },
    ]
    return (
        <View style={{ flex: 1, paddingHorizontal: width(4) }}>
            <Text style={styles.TextA}>Result Card</Text>

            <View>
                <Text>Name: Yahya</Text>
                <Text>Class: Class 1 / Section A</Text>
            </View>

            <View style={styles.flatlistView}>
                <View style={styles.mainView}>
                    <Text>Subject</Text>
                    <View style={styles.secondView}>
                        <Text>Total</Text>
                        <Text>Obtain</Text>
                    </View>
                </View>

                <FlatList
                    data={data}
                    renderItem={({ item, index }) => {
                        return (
                            <View style={{ ...styles.mainView, marginVertical: 10 }}>
                                <Text>{item?.subject}</Text>
                                <View style={styles.secondView}>
                                    <Text>{item?.total}</Text>
                                    <Text>{item?.obtain}</Text>
                                </View>
                            </View>
                        )
                    }}
                />

                <View style={{ ...styles.mainView, marginTop: 30 }}>
                    <Text>Total</Text>
                    <View style={styles.secondView}>
                        <Text>300</Text>
                        <Text>140</Text>
                    </View>
                </View>

                <View style={styles.gradeView}>
                    <View>
                        <Text>Grade</Text>
                        <Text style={{ marginTop: height(2) }}>Percentage</Text>
                    </View>

                    <View>
                        <Text>C</Text>
                        <Text style={{ marginTop: height(2) }}>45%</Text>
                    </View>
                </View>
            </View>

        </View>
    )
}

export default veiwResult

const styles = StyleSheet.create({
    TextA: {
        alignSelf: 'center',
        fontWeight: 'bold',
        marginTop: 10,
        fontSize: 20,
    },
    flatlistView: {
        backgroundColor: "gray",
        padding: width(4),
        borderRadius: 10,
        marginTop: 20
    },
    mainView: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: "white",
        padding: 15,
        borderRadius: 10
    },
    secondView: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: "center",
        width: width(35)
    },
    gradeView: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: "white",
        padding: 15,
        borderRadius: 10,
        marginTop: height(5),
        width: width(60),
        alignSelf: 'center'
    },
})