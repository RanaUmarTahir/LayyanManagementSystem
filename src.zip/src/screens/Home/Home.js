import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Button } from 'react-native'
import React, { useState } from 'react'
import { width, height } from 'react-native-dimension'
import { appColors } from '../../colors'
import { appImages } from '../../constants'
import Modal from "react-native-modal";

const Home = (props) => {
  const [isModalVisible, setModalVisible] = useState(false);

  return (
    <View>
      <View style={styles.topView}>
        <View style={styles.headers}>
          <Text style={styles.textA}>
            Hi, Yahya
          </Text>
          <Text style={styles.textB} onPress={() => setModalVisible(!isModalVisible)}>logout</Text>
        </View>
        <TouchableOpacity onPress={() => props.navigation.navigate('studentProfile')}>
          <Image style={styles.image}
            resizeMode='contain'
            tintColor={appColors.black}
            source={appImages.profile} />

        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: height(10) }}>
        <View style={styles.background}>

          <TouchableOpacity
            onPress={() => props.navigation.navigate('viewAnnouncement')} style={styles.mainView}>
            <Image source={appImages.announcement} resizeMode='contain' style={styles.imageA} />
            <Text>
              View Announcment
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => props.navigation.navigate('veiwAttendance')}
            style={styles.mainView}>
            <Image source={appImages.attendance} resizeMode='contain' style={styles.imageA} />
            <Text>
              View Attendance
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => props.navigation.navigate('veiwResult')}
            style={styles.mainView}>
            <Image source={appImages.result} resizeMode='contain' style={styles.imageA} />
            <Text>
              View Result
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => props.navigation.navigate('ContactUs')} style={styles.mainView}>
            <Image source={appImages.contactUs} resizeMode='contain' style={styles.imageA} />
            <Text>
              Contact Us
            </Text>
          </TouchableOpacity>


        </View>
      </ScrollView>

      <Modal
        isVisible={isModalVisible}
        style={{ backgroundColor: "blue" }}
      >
        <View style={{ backgroundColor: "red", justifyContent: 'center', alignItems: "center", alignSelf: 'center' }}>
          <Text>Hello!</Text>

          <Button title="Hide modal" onPress={() => setModalVisible(!isModalVisible)} />
        </View>
      </Modal>

    </View>
  )
}
const styles = StyleSheet.create({
  mainView: {
    alignItems: 'center',
    backgroundColor: 'white',
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 10,
    padding: 20,
  },
  topView: {
    flexDirection: "row",
    justifyContent: 'space-between',
    margin: 10,
  },
  textA: {
    fontWeight: 'bold',
  },
  textB: {
    color: 'red',
  },
  image: {
    height: width(15),
    width: width(15),
    // marginRight: 7,
  },
  headers: {
    marginLeft: 10,
  },
  background: {
    // height: 5000,
    borderRadius: 20,
    weight: 40,
    marginVertical: 30,
    paddingBottom: 20,
    margin: 10,
    backgroundColor: 'gray',
  },
  imageA: {
    height: width(30),
    weight: width(30),
    alignSelf: 'center',
    margin: 10,

  },
  textC: {
    align: 'content',
  }

})
export default Home
