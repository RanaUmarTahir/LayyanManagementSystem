import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList } from 'react-native'
import React from 'react'
import { height, width } from "react-native-dimension"
import { appImages } from '../../constants'
import { appColors } from '../../constants/colos'
import { Spacer } from '../../components/spacer'
import { HomeCard } from '../../components/homeCard'
import teacherList from '../teacherlList'


const adminLogin = (props) => {
    const homeCard = [

        {
            name: 'Teacher',
            icon: appImages.profile,
            route: 'teacherList',
        },
        {
            name: 'Student',
            icon: appImages.profile,
            route: 'studentList',
        },
        {
            name: 'Classes',
            icon: appImages.profile,
        },
        {
            name: 'Attendance',
            icon: appImages.attendance,
        },
        {
            name: 'Result',
            icon: appImages.result,
        },
        {
            name: 'Announcements',
            icon: appImages.announcement,
        },
    ]
    const renderItem = ({ item }) => {
        return <HomeCard name={item.name}
            icon={item.icon}
            onPress={() => props.navigation.navigate(item.route)} />
    }
    return (
        <View style={styles.sectionContainer} >
            <View style={styles.header}>
                <View>
                    <Text style={styles.texta}>Hi, Admin</Text>

                    <Text style={styles.textb}>Logout</Text>

                </View>
                <Image style={styles.profile} source={appImages.profile} />
            </View>
            <View style={styles.backgound}>
                <FlatList data={homeCard} renderItem={renderItem} />
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    sectionContainer: {
        flex: 1,
        margin: 10,
    },
    header: {
        height: 40,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    texta: {
        fontWeight: 'bold',
        fontSize: 20,
    },
    textb: {
        fontWeight: 'bold',
        fontSize: 16,
        color: 'red',
    },
    profile: {
        height: 80,
        width: 80,
    },
    backgound: {
        margin: 10,
        padding: 10,
        backgroundColor: "gray",
        borderRadius: 20,
        alignItems: 'center',

    },
    card: {
        height: height(30),
        width: width(80),
        backgroundColor: appColors.white,
        borderRadius: 20,
        margin: 10,
        padding: 10,
        alignItems: 'center',
        justifyContent: 'center',
    },
    cardImage: {
        height: height(20),
        width: height(20),
        resizeMode: 'contain',
        tintColor: appColors.blue,
    },
    cardText: {
        fontWeight: 'bold',
        fontSize: 20,
        color: appColors.blue,
    },
})
export default adminLogin