import { View, Text, StyleSheet, Image } from 'react-native'
import React from 'react'
import { width } from "react-native-dimension";
import { appImages } from '../../constants';

const studentProfile = () => {
    return (
        <View>
            <Text style={styles.header}>Student Profile</Text>
            <View style={styles.mainView} >

                <Image style={styles.image} resizeMode='contain'
                    source={appImages.profile} />

                <View style={styles.textView}>
                    <View>
                        <Text>Name</Text>
                        <Text>Phone No.</Text>
                        <Text>Class</Text>
                        <Text>Email</Text>
                    </View>

                    <View>
                        <Text>M Yahya</Text>
                        <Text>64940610168</Text>
                        <Text>Class1/SectionA</Text>
                        <Text>yahyaakram616@gmail.com</Text>
                    </View>
                </View>





            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    header: {
        alignSelf: 'center',
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 10,

    },
    mainView: {
        margin: 50,
        borderRadius: 10,
        borderWidth: 2,
        borderColor: 'black',
        // backgroundColor: "red",
        padding: 10,
    },
    image: {
        height: width(12),
        width: width(12),
        alignSelf: 'center',
    },
    textView: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 10,
    },
})
export default studentProfile