
import React, { useState } from 'react';
import {
    StyleSheet,
    Image,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';

import Navigation from '../../Navigations';
import Home from '../Home/Home';
import { StackActions } from '@react-navigation/native'
import { appImages } from '../../constants';


const Login = (props) => {
    const userType = props?.route?.params?.screen || ''
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')

    return (

        <View style={styles.sectionContainer}>
            <Image style={styles.image}
                source={appImages.logo}
            />
            <Text style={styles.text}>Login</Text>
            <View style={styles.view}>
                <Text style={styles.inputText}>Enter Email or Username</Text>
                <TextInput
                    value={email}
                    onChangeText={(text) => {
                        setEmail(text)
                        setError('')
                    }}
                    style={styles.input}
                    placeholder='Email or Username'
                />
                <Text style={styles.inputText}>Enter Password</Text>
                <TextInput
                    value={password}
                    onChangeText={(text) => {
                        setPassword(text)
                        setError('')
                    }}
                    style={styles.input}
                    placeholder='Password'
                    secureTextEntry={true}
                />
            </View>

            <Text style={styles.error} >{error}</Text>

            <TouchableOpacity>
                <Text style={styles.forgetpassword} >
                    Forget Password?
                </Text>

            </TouchableOpacity>
            <View style={styles.space}></View>
            <TouchableOpacity
                style={styles.button}
                onPress={() => {
                    if (userType == 'admin') {
                        if (email == 'admin@gmail.com' && password == 'admin123') {
                            props.navigation.dispatch(StackActions.replace('mainStack', {
                                screen: 'adminLogin'
                            }))
                        } else {
                            if (email == '' || password == '') {
                                setError('Please enter username or password!')
                            } else {
                                setError('Invalid Username or password!')
                            }
                        }
                    } else if (userType == 'teacher') {
                        props.navigation.dispatch(StackActions.replace('mainStack', {
                            screen: 'Teacherhome'
                        }))
                    } else {
                        props.navigation.dispatch(StackActions.replace('mainStack', {
                            screen: 'Home'
                        }))
                    }
                }
                }>
                <Text style={styles.buttonText}>
                    Login
                </Text>

            </TouchableOpacity>
        </View>

    );


}

const styles = StyleSheet.create({
    sectionContainer: {
        flex: 1,
    },
    image: {
        height: 200,
        width: 200,
        marginTop: 50,
        alignSelf: "center",
    },
    text: {
        fontSize: 30,
        fontWeight: 'bold',
        alignSelf: 'center',
        marginTop: 20,
    },
    view: {
        marginTop: 30,
    },

    input: {
        backgroundColor: "white",
        fontSize: 12,
        width: 350,
        fontFamily: "verdana",
        color: "black",
        borderWidth: 2,
        borderColor: "black",
        marginHorizontal: 10,
        marginTop: 5,
        borderRadius: 10,
        paddingHorizontal: 10,
        height: 45,
        alignSelf: 'center',
    },
    inputText: {
        marginLeft: 20,
        marginTop: 8,
    },
    space: { marginTop: 30, },
    buttonText: {
        fontSize: 14,
        fontFamily: "verdana",
        color: "white",
    },

    forgetpassword: {
        fontSize: 16,
        alignSelf: "flex-end",
        fontFamily: "verdana",
        color: "#223a80",
        marginTop: 10,
        marginRight: 20,
    },
    error: {
        fontSize: 16,
        fontFamily: "verdana",
        color: "red",
        marginTop: 10,
        marginHorizontal: 20
        // marginRight: 20,
    },

    button: {
        backgroundColor: "#223a80",
        borderWidth: 1,
        marginHorizontal: 10,
        marginTop: 10,
        borderRadius: 40,
        alignItems: "center",
        height: 39,
        width: 300,
        justifyContent: 'center',
        alignSelf: 'center',
    },

});
export default Login;
