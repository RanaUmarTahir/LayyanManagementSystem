export const appImages = {
    logo: require('../images/logo.png'),
    attendance: require('../images/attendance.png'),
    announcement: require('../images/announcement.png'),
    result: require('../images/result.png'),
    edit: require('../images/edit.png'),
    delete: require('../images/delete.png'),
    add: require('../images/add.png'),
    contactUs: require('../images/contactUs.png'),
    profile: require('../images/noUser.png'),
}