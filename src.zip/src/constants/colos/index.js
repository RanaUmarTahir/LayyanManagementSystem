export const appColors = {
    lightgrey: '#d9dadb',
    white: "#FFFFFF",
    black: "#000000",
    gray: "#545F71",
    darkBlue: "#232A3C",
    silver: "#EEF1F4",
    blue: '#213b70',
    red: '#f00226',
}